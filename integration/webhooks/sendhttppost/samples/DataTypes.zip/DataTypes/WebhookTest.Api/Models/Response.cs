﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebhookTest.Api.Models
{
    public class Response
    {
        public string Date_Utc_Now { get; set; }
        public int Two_Squared_Number { get; set; }
        public string Hello_Name { get; set; }
    }
}