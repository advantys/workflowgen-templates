﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebhookTest.Api.Models
{
    public class PayloadObject
    {
        public string payload { get; set; }
    }
}